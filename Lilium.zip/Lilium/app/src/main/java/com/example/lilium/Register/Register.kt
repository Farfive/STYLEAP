package com.example.lilium.Register

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import com.example.lilium.Form.Form
import com.example.lilium.R
import com.example.lilium.Select.Select

class Register : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)
        val nextbtn = findViewById<Button>(R.id.nextbtn)

        nextbtn.setOnClickListener() {
            val intent = Intent(this, Select::class.java)
            startActivity(intent)
        }
    }
}