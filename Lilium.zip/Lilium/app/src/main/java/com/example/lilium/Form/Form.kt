package com.example.lilium.Form

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import com.example.lilium.R

class Form : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_form)

         val btnForm = findViewById(R.id.btnForm) as Button

        //ustawić przejście do następnego activity
        btnForm.setOnClickListener{
            intent = Intent()
        }


    }
}