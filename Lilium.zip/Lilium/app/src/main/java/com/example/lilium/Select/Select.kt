package com.example.lilium.Select

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import com.example.lilium.Form.Form
import com.example.lilium.Map.Map
import com.example.lilium.R
import com.google.android.gms.maps.MapFragment

class Select : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_select)
        val klientbtn = findViewById<Button>(R.id.klientbtn)
        val firmabtn = findViewById<Button>(R.id.firmabtn)

        klientbtn.setOnClickListener() {
            val intent = Intent(this, Map::class.java)
            startActivity(intent)
        }

        firmabtn.setOnClickListener() {
            val intent = Intent(this, Form::class.java)
            startActivity(intent)
        }
    }
}